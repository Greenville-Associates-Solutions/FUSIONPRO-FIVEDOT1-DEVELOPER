# Magento 2 Functional Tests

The Functional Tests Module for **Magento_ConfigurableProductCatalogSearch** Module.
