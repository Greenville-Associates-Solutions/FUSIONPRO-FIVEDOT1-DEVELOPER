<?php

require_once('Thing.php');

class BxDolMistake extends Thing
{
    public function __construct(){}

    public function log($s) {}

    public function displayError() {}
}
